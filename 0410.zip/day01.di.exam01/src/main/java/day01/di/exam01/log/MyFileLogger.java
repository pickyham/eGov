package day01.di.exam01.log;

public class MyFileLogger extends MyLogger {
	
	private String filename;

	//source - generate constructure using Field
	//근데 이렇게 하면 xml파일에 문제 생김
	//1.해결법 기본 생성자 (의미없음)
	//2.해당 bean 안에 Constructor-arg ref를 xml에 넣어줌
	public MyFileLogger(String filename) {
		super();
		this.filename = filename;
	}

	@Override
	public void log(String string) {
		System.out.println("File Log : " + string);
	}

}
