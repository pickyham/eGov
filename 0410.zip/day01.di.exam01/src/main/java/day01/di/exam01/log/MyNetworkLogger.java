package day01.di.exam01.log;

public class MyNetworkLogger extends MyLogger{


	@Override
	public void log(String string) {
		System.out.println("network Log :" +string);
		
	}

}
