package day01.di.exam01.service;

public interface IHelloService {

	String sayHello();

}