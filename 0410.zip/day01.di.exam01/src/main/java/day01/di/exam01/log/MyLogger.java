package day01.di.exam01.log;

public abstract class MyLogger {//abstract이라서 객체 생성할 필요없음 상속받으면 알아서 하세여!

	public abstract void log(String string) ;//강제로라도 반드시 상속하도록 만듬 (버그 안생기게)

}
