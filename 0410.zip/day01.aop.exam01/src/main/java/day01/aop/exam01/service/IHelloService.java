package day01.aop.exam01.service;

public interface IHelloService {

	String sayHello(String string);

}