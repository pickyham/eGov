package day01.aop.exam01.service;

public class HelloService implements IHelloService {

	public String sayHello(String string) {
		return "안녕하세요 " + string;
	}

}
