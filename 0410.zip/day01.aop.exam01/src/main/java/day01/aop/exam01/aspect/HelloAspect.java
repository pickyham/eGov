package day01.aop.exam01.aspect;

public class HelloAspect { //Aspect
	public void before() { //Advice
		System.out.println("실행전...");
	}

}
