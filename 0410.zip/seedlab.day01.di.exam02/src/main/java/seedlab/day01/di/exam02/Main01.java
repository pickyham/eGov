package seedlab.day01.di.exam02;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import seedlab.day01.di.exam02.service.CalcService;
import seedlab.day01.di.exam02.service.IHelloService;

public class Main01 {

	public static void main(String[] args) {
		//1. 스프링 빈 설정파일 작성 (app.xml)
		//2. 빈 클래스 작성(업무코드)
		//3. 테스트 코드
		
		// 환경조성

		//ClassPathXmlApplicationContext - 
		String configLocation = "app.xml"; //클래스 등록 하는 놈 
		BeanFactory context = new FileSystemXmlApplicationContext(configLocation);
		//자식 타입놈 중 하나만 등록 가능(여러개는 안됌-name으로 검색하면 가능)
		IHelloService hs = context.getBean(IHelloService.class); 
		
		///////////
		
		String r = hs.sayHello();
		System.out.println(r);
		
		//////////////////////////
		
		CalcService cs = context.getBean(CalcService.class);
		int cr = cs.plus(2,3);
		System.out.println("2 + 3 = " + cr); // 2 + 3 = 5;
//		
//		CalcService cs2 = context.getBean(CalcService.class);
//		System.out.println(cs == cs2); //xml scope singleton, prototype 차이 확인 p2-33
//		System.out.println(new String("a")  == new String("a")); //새로운 주소값1 != 새로운 주소값2
	}

}
