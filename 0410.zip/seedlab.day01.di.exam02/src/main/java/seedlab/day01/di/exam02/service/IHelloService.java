package seedlab.day01.di.exam02.service;

public interface IHelloService {

	String sayHello();

}