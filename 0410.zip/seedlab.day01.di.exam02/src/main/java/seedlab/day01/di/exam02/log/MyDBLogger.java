package seedlab.day01.di.exam02.log;

import org.springframework.stereotype.Component;

@Component
public class MyDBLogger extends MyLogger {
//	생성자 메서드(삭제)
//	public MyDBLogger() {
//		// TODO Auto-generated constructor stub
//	}

	@Override
	public void log(String string) {
		System.out.println("DB Log :" +string);

	}

}
