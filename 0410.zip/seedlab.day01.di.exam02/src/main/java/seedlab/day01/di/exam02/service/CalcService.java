package seedlab.day01.di.exam02.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import seedlab.day01.di.exam02.log.MyLogger;

@Component
public class CalcService implements BeanNameAware{
//	@Autowired
//	@Qualifier("myDBLogger")
	
	@Resource(name="myNetworkLogger")
	private MyLogger logger; // = new myFilelogger();
	
	//bean에서 property에서 name을 가지고 올수 있음
	//만약 여러개라면? - xml파일에서 여러개 나옴

//	public void setLogger(MyLogger logger) {
//		this.logger = logger;
//	}
	
	public int plus(int i, int j) {
		//요구사항 : console, file, network, not
		logger.log(i+"+"+j);
		return i+j;
	}

	@Override
	public void setBeanName(String beanname) {
		System.out.println("CalcService의 id는 " + beanname); //로그찍을때 확인 가능
	}

}
