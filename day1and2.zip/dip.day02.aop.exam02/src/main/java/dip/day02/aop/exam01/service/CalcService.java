package dip.day02.aop.exam01.service;

import org.springframework.stereotype.Component;

@Component
public class CalcService implements ICalcService {

	/* (non-Javadoc)
	 * @see dip.day02.aop.exam01.service.ICalcService#plus(int, int)
	 */
	@Override
	public int plus(int i, int j) {
		return i+j;
	}
}

