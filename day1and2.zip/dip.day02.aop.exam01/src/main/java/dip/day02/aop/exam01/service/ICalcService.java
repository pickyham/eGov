package dip.day02.aop.exam01.service;

public interface ICalcService {

	int plus(int i, int j);
}
