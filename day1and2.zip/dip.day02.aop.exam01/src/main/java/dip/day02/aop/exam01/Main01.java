package dip.day02.aop.exam01;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import dip.day02.aop.exam01.service.CalcService;
import dip.day02.aop.exam01.service.ICalcService;

public class Main01 {

	public static void main(String[] args) {
		/*
		 * 1. XML로더 생성( app.xml 작성 )
		 * 2. bean 검색  getBean() ( 업무클래스 작성 )
		 * 3. 비즈니스 메서드 호출
		 */
		String configLocation="app.xml";
		ApplicationContext context = 
				new FileSystemXmlApplicationContext(configLocation);
		ICalcService cs = context.getBean(ICalcService.class);
		int r = cs.plus( 2,3 );
		System.out.println( "2+3="+r );
	}
}
