package dip.day01.aop.exam01.service;

public class HelloService implements IHelloService {

	/* (non-Javadoc)
	 * @see dip.day01.aop.exam01.service.IHelloService#sayHello(java.lang.String)
	 */
	@Override
	public String sayHello(String string) {
		return "안녕하세요 "+string;
	}

}
