package dip.day01.di.exam01.service;

import org.springframework.beans.factory.BeanNameAware;

import dip.day01.di.exam01.log.MyConsoleLogger;
import dip.day01.di.exam01.log.MyFileLogger;
import dip.day01.di.exam01.log.MyLogger;

public class CalcService implements BeanNameAware {
	
	private MyLogger logger; // = new MyFileLogger();//console, File, Network, Not
	
	public void setLogger(MyLogger logger) {
		this.logger = logger;
	}
	
	public int plus(int i, int j) {
		logger.log( i+"+"+j );
		return i+j;
	}

	@Override
	public void setBeanName(String beanname) {
		System.out.println( "CalcService의 id는 "+beanname);
	}

}
