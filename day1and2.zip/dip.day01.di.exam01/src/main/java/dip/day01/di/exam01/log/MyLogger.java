package dip.day01.di.exam01.log;

public abstract class MyLogger {

	public abstract void log(String string) ;

}
