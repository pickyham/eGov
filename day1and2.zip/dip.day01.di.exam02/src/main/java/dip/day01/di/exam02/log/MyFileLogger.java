package dip.day01.di.exam02.log;

public class MyFileLogger extends MyLogger {
	
	private String filename;
	
	public MyFileLogger(String filename) {
		super();
		this.filename = filename;
	}

	@Override
	public void log(String string) {
		System.out.println("File Log:"+string);
	}

}
