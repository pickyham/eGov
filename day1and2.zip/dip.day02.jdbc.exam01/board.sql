
create table board(
  no integer auto_increment,
  title varchar(100),
  writer varchar(100),
  content varchar(4000),
  regdate date,
  primary key(no)
)
