package dip.day02.jdbc.exam01;


import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Main01 {

	public static void main(String[] args) throws SQLException {
		String configLocation="app.xml";
		ApplicationContext context = 
				new FileSystemXmlApplicationContext(configLocation);
		// DB연결
		JdbcTemplate temp = context.getBean(JdbcTemplate.class);
		String sql="INSERT INTO BOARD(title,writer,content,regdate)";
		sql += "values(?,?,?,now())";
		int ret = temp.update(sql, "두번째 제목","아까그놈","아깝당2");
		System.out.println("등록성공~~");
	}

}
