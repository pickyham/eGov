package dip.day02.jdbc.exam01;


import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class Main2_Select {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws SQLException {
		String configLocation="app.xml";
		ApplicationContext context = 
				new FileSystemXmlApplicationContext(configLocation);
		// DB연결
		JdbcTemplate temp = context.getBean(JdbcTemplate.class);
		String sql="SELECT COUNT(*) FROM BOARD";
		int count = temp.queryForObject(sql, Integer.class);
		System.out.println("저장갯수는 "+count);
		//
		sql = "SELECT * FROM BOARD WHERE no=1"; 
		Map<String, Object> map = temp.queryForMap(sql);
		System.out.println(map);
		//
		sql = "SELECT * FROM BOARD WHERE no=1"; 
		RowMapper rowMapper = new BeanPropertyRowMapper<>(BoardVO.class);
		BoardVO vo = (BoardVO) temp.queryForObject(sql, rowMapper);
		System.out.println("boardvo = "+vo);
		//
		sql = "SELECT * FROM BOARD ORDER BY no desc";
		List<BoardVO> list = temp.query(sql, rowMapper);
		for (BoardVO vo2 : list) {
			System.out.println("query: "+vo2);
		}
	}

}
